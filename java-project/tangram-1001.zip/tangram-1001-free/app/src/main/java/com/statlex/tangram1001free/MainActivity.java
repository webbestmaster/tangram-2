package com.statlex.tangram1001free;

import android.os.Bundle;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.Tracker;


//admob
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    // back button
    private static long backButtonPressedTimeStamp;

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            if (backButtonPressedTimeStamp + 2000 > System.currentTimeMillis()) {
                super.onBackPressed();
            } else {
                Toast.makeText(getBaseContext(), "Press again to exit.",
                        Toast.LENGTH_SHORT).show();
            }
            backButtonPressedTimeStamp = System.currentTimeMillis();
        }
    }

    // activity state
    private static boolean isActivityVisible = true;

    public static boolean getIsActivityVisible() {
        return isActivityVisible;
    }

    public static void activityResumed() {
        isActivityVisible = true;
    }

    public static void activityPaused() {
        isActivityVisible = false;
    }

    // admob
    @JavascriptInterface
    public void displayInterstitial() {
        if (getIsActivityVisible()) {
            messageHandler.sendEmptyMessage(0);
        }
    }

    // audio player state
    private AudioInterface audioInterface_0;
    private AudioInterface audioInterface_1;
    private AudioInterface audioInterface_2;
    private AudioInterface audioInterface_3;

    @Override
    protected void onDestroy() {
        activityPaused();
        audioInterface_0.release();
        audioInterface_1.release();
        audioInterface_2.release();
        audioInterface_3.release();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        activityPaused();
        audioInterface_0.pause();
        audioInterface_1.pause();
        audioInterface_2.pause();
        audioInterface_3.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        activityResumed();
        audioInterface_0.unPause();
        audioInterface_1.unPause();
        audioInterface_2.unPause();
        audioInterface_3.unPause();
        super.onResume();
    }


    public static GoogleAnalytics analytics;
    public static Tracker tracker;

    private WebView webView;


    //admob
    private InterstitialAd mInterstitialAd;

    //admob
    private void initializeInterstitialAd() {
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        List<String> testDeviceIds = Collections.singletonList("emulator-5554");
        RequestConfiguration configuration =
                new RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build();
        MobileAds.setRequestConfiguration(configuration);

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-1163262106536779/3033767695");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());

        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        });
    }

    //admob
    private Handler messageHandler = new Handler() {
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                Log.d("TAG", "The interstitial wasn't loaded yet.");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        analytics = GoogleAnalytics.getInstance(this);
        analytics.setLocalDispatchPeriod(1800);

        tracker = analytics.newTracker("UA-53856001-2"); // Replace with actual tracker/property Id
        tracker.enableExceptionReporting(true);
        tracker.enableAdvertisingIdCollection(true);
        tracker.enableAutoActivityTracking(true);

        setContentView(R.layout.activity_main);

        audioInterface_0 = new AudioInterface(this);
        audioInterface_1 = new AudioInterface(this);
        audioInterface_2 = new AudioInterface(this);
        audioInterface_3 = new AudioInterface(this);

        webView = (WebView) findViewById(R.id.webView);

        webView.addJavascriptInterface(audioInterface_0, "AndAud_0");
        webView.addJavascriptInterface(audioInterface_1, "AndAud_1");
        webView.addJavascriptInterface(audioInterface_2, "AndAud_2");
        webView.addJavascriptInterface(audioInterface_3, "AndAud_3");

        webView.addJavascriptInterface(this, "Android");

        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        settings.setDatabaseEnabled(true);
        String dbPath = this.getApplicationContext()
                .getDir("database", Context.MODE_PRIVATE).getPath();
        settings.setDatabasePath(dbPath);

        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(true);
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);

        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        // set volume
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 2, 0);

        initializeInterstitialAd();

/*
        webView.setWebChromeClient(new WebChromeClient() {
            public void onConsoleMessage(String message, int lineNumber,
                                         String sourceID) {
                Log.d("MyApplication", message + " -- From line " + lineNumber
                        + " of " + sourceID);
            }

            @Override
            public void onExceededDatabaseQuota(String url,
                                                String databaseIdentifier, long currentQuota,
                                                long estimatedSize, long totalUsedQuota,
                                                WebStorage.QuotaUpdater quotaUpdater) {
                quotaUpdater.updateQuota(estimatedSize * 2);
            }

        });
*/

        webView.loadUrl("file:///android_asset/www/index.html");

        // admob
//        AdView adView = (AdView) this.findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder()
//                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
//                .addTestDevice("9C68F80BF392A2C03C75BC66CA25A827")
//                .build();
//        adView.loadAd(adRequest);

    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

}